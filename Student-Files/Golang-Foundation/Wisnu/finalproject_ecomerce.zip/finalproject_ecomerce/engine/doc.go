// Package engine represents the use-cases layer
package engine
