package engine

type (
	// EventType ...
	EventType uint16
)

// Event types
const (
	TokenGenerated EventType = iota
)
