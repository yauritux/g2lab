// Package domain represents the domain layer
package domain
